package com.example.faceflowjava.dao;

import com.example.facematrix.FaceMatrix;
import com.google.protobuf.InvalidProtocolBufferException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Service
@Transactional
public class FaceDaoImpl implements FaceDao {
    @Resource
    private JdbcTemplate jdbcTemplate;

    public Map<String, double[]> loadAll() {
        Map<String, double[]> ret = new HashMap<>();
        jdbcTemplate.query("SELECT f.id,f.matrix FROM face.face_matrix f", new RowCallbackHandler() {
            @Override
            public void processRow(ResultSet resultSet) throws SQLException {

                try {
                    String id = resultSet.getString(1);
                    byte[] bytes = resultSet.getBytes(2);
                    FaceMatrix.Matrix matrix = FaceMatrix.Matrix.parseFrom(bytes);
                    ret.put(id, matrix
                            .getMatrixList()
                            .stream()
                            .mapToDouble(Double::doubleValue)
                            .toArray());
                } catch (InvalidProtocolBufferException e) {
                    e.printStackTrace();
                }
            }
        });
        return ret;
    }

    @Override
    public double[] findByID(String id) {
        try {
            byte[] bytes = jdbcTemplate.queryForObject("select matrix from face_matrix where id =? ",
                    new String[]{id}, byte[].class);
            FaceMatrix.Matrix matrix = FaceMatrix.Matrix.parseFrom(bytes);
            return matrix
                    .getMatrixList()
                    .stream()
                    .mapToDouble(Double::doubleValue)
                    .toArray();
        } catch (InvalidProtocolBufferException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int save(String id, FaceMatrix.Matrix matrix) {
        int update = jdbcTemplate.update("INSERT INTO face_matrix (`id`, `matrix`) VALUES (?, ?)",
                id, matrix.toByteArray());
        return update;
    }
}

package com.example.faceflowjava.dao;

import com.example.facematrix.FaceMatrix;

import java.util.Map;

public interface FaceDao {
    Map<String,double[]> loadAll();
    double[] findByID(String id);
    int save(String id, FaceMatrix.Matrix matrix) ;
}

package com.example.faceflowjava.action;

import com.example.faceflowjava.dao.FaceDao;
import com.example.faceflowjava.grpc.FaceFlowClient;
import com.example.facematrix.FaceIdentity;
import com.example.facematrix.FaceMatrix;
import com.google.protobuf.ByteString;
import org.apache.commons.math3.ml.distance.EuclideanDistance;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.constraints.NotBlank;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/register")
public class FaceRegisterController implements InitializingBean {
    public static final String DB_BASE = ".\\db";
    @Autowired
    FaceFlowClient client;
    @Autowired
    FaceDao faceDao;

    public static final Map<String, double[]> dbCache = new ConcurrentHashMap<>();


    @RequestMapping("/index")
    public String index(Map model) {
        model.putIfAbsent("message", "Facenet meets Tensorflow!");
        model.putIfAbsent("matches", "");
        return "register/index";
    }

    @RequestMapping("/add")
    public String add(@RequestParam("face1") MultipartFile face1,
                      @NotBlank @RequestParam(value = "id", required = true) String id,
                      RedirectAttributes redirectAttributes) throws IOException {
        FaceMatrix.Matrix matrix1 = getMatrix(face1.getBytes());
        double[] doubles1 = matrix1
                .getMatrixList()
                .stream()
                .mapToDouble(Double::doubleValue)
                .toArray();
        faceDao.save(id, matrix1);
        dbCache.put(id, doubles1);
        redirectAttributes.addFlashAttribute("message",
                "successfully!");
        return "redirect:/register/index";
    }

    @RequestMapping("/identify")
    public String identify(@RequestParam("face") MultipartFile face,
                           RedirectAttributes redirectAttributes) throws IOException {
        FaceMatrix.Matrix matrix = getMatrix(face.getBytes());
        List<String> ids = dbCache
                .entrySet()
                .stream()
                .filter(t -> {
                    double compute = new EuclideanDistance().compute(
                            t.getValue(), unwrap(matrix));
                    return compute < 1.0;
                })
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
        redirectAttributes.addFlashAttribute("matches", ids
                .stream()
                .collect(Collectors.joining(",")));
        return "redirect:/register/index";
    }

    private FaceMatrix.Matrix getMatrix(byte[] file) {
        FaceMatrix.Face face = FaceMatrix.Face
                .newBuilder()
                .setFace(ByteString.copyFrom(file))
                .build();
        return client.getMatrix(face);
    }

    private static double[] unwrap(FaceMatrix.Matrix matrix) {
        return matrix
                .getMatrixList()
                .stream()
                .mapToDouble(Double::doubleValue)
                .toArray();
    }

    private static double[] unwrap(FaceIdentity.Identity matrix) {
        return matrix
                .getMatrixList()
                .stream()
                .mapToDouble(Double::doubleValue)
                .toArray();
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        dbCache.putAll(faceDao.loadAll());
    }
}

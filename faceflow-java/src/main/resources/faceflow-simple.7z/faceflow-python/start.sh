#!/usr/bin/env/bash

export PYTHONPATH=$PYTHONPATH:./lib:.
./python36/bin/python3.6 ./facematrix/face_server.py
